﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParticleSystemScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Debug.Log("I AM ALIVE");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
